// assignmental operator +=,-=,*=,/=,%=  
class Assignmental{
  public static void main(String[] args){
    int x=10,y=20,z=x+y;
    int a=15,b=15,c=16,d=10,e=3;     
    a+=5;
    b-=1;
    c*=2;
    d/=5;
    e%=3;                  
  
    System.out.println(z);
    System.out.println(a);
    System.out.println(b);
    System.out.println(c);
    System.out.println(d);
    System.out.println(e);
    
  }
}