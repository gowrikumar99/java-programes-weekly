// Arthematic operator +,-,*,%,/
class Arthematic{
  public static void main(String[] args){
    int x=20, y=15;
    
    System.out.println(x+y);
    System.out.println(x-y);
    System.out.println(x*y);
    System.out.println(x/y);
    System.out.println(x%y);
    
  }
}