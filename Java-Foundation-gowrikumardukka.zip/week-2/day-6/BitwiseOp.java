class BitwiseOp{
  public static void main(String[] args){
    int a=10,b=40;
    System.out.println("bitwise and operatoe(&) :" +(a&b));
    System.out.println("bitwise or operatoe(|) :" +(a|b));
    System.out.println("bitwise not operatoe(^) :" +(a^b));
    System.out.println("bitwise left shift operatoe(<<) :" +(a<<b));
    System.out.println("bitwise right shift operatoe(>>) :" +(a>>b));
    
  }
}