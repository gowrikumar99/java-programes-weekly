/* Write a program to calculate the circumference of a circle and print the result in whole number. 
  Allow user to input the cirlce radius from terminal. 
  Sample Input:
    radius of the circle=6
  Expected Output:
   Circumference of the circle=38
   
*/ 
class CircuferenceOfCircle{
  public static void main(String[] args){
      int r=6;   //radius of citcle
        System.out.println("circumference of circle");
        System.out.println("circumference of circle :"+(2*3.14*r));     //circumference of circle=2*3.13*r

  
  }
}