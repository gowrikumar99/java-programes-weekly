class PerimeterOfRectangle{
  public static void main(String[] args){
    int a=100,b=200,c= a+b,d=2*(a+b);
    System.out.println(d);
  }
}