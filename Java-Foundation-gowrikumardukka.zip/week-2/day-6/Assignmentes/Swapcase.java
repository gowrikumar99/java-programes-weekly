class Swapcase{
  public static void main(String[] args){
    int x=12,y=45;
    x=x+y;
    y=x-y;
    x=x-y;
    System.out.print(x+" "+y);
  }
}