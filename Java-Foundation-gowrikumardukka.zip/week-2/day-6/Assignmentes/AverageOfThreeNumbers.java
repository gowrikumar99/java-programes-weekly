class AverageOfThreeNumbers{
  public static void main(String[] args){
    int a=10,b=20,c=30 ,d=a+b+c;
    int average=(d/3);
    
    System.out.println(average);
  }
}