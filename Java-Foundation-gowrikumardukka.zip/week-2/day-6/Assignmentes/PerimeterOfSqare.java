class PerimeterOfSqare{
  public static void main(String[] args){
    //perimeterofsquare p=side*4
    int a=100,b=4*a;
    System.out.println(b);
  }
}