class AreaOfRectangle{
  public static void main(String[] args){
    // area of rectangle(a)=lengnth*breadth
    int a=10, b=20,c=a*b;
    System.out.println(c);
  }
}