class Boolen{
  public static void main(String[] args){
    
    
    boolean a = true,b = false;
    boolean value = a == b;
    System.out.println("value= " + value);
  }
}