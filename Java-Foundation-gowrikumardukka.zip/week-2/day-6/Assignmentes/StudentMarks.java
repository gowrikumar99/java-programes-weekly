class StudentMarks{
  public static void main(String[] args){
    //percentage (studentmarks/totalmarks)*100
    double a=10,b=20,c=30,d=40,e=50;
    double percentage=((a+b+c+d+e)/500)*100;
    
    System.out.println("percentage :" +percentage);
  }
}