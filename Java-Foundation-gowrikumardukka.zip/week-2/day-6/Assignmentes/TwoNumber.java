class TwoNumber{
  public static void main(String[] args){
    int a=10,b=20,c=30;
    System.out.println("this values are equal (30,20) : " +(c==b));
    System.out.println("this values are equal (20,20) : " +(b==b));
    System.out.println("this values are equal (20,30) : " +(b==c));
  }
}