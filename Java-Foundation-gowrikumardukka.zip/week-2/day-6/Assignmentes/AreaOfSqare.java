class AreaOfSqare{
  public static void main(String[] args){
    int a=10,b=a*a;
    System.out.println(b);
  }
  
}