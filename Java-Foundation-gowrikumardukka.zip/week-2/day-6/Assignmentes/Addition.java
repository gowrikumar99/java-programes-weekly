class Addition{
  public static void main(String[] args){
    int a=12,b=13, c=14 ,d=a+b+c;
    System.out.println(d);
  }
}