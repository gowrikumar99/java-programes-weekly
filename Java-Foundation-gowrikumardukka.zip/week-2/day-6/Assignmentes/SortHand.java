class SortHand{
  public static void main(String[] arga){
  int a=10,b=20;
    System.out.println(a*=b);
    System.out.println(a-=b);
    System.out.println(a/=b);
    System.out.println(a%=b);
  }
}