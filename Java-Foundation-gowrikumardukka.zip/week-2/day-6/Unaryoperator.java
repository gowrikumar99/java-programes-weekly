class Unaryoperator{
  public static void main(String[] args){
    int a=-10;
    int b=20;
    int c=15;
    int d=4;
    int e=30;
    int f=30;
    System.out.println("this a value : " +(a));
    
    System.out.println("this b value : " +(-b));
    
    System.out.println("this c value : " +(c++));
    System.out.println("this c value : " +(c++));
    
    System.out.println("this d value : " +(d--));
    System.out.println("this d value : " +(d--));
    
    System.out.println("this e value : " +(++e));
    
    System.out.println("this f value : " +(f++));
  }
}