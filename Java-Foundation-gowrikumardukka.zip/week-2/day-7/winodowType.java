
import java.util.Scanner;
class winodowType
  {
    public static void main(String args[])
    {
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the value");
      double number=sc.nextDouble();
      int value=(int)number;
      System.out.println(value);
                        
    }
  }