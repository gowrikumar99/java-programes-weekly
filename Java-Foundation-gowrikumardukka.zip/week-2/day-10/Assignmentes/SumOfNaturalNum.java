//sum of n naturalnumbers
import java.util.Scanner;
class SumOfNaturalNum 
{  
public static void main(String[] args)   
{   
int i=1, num = 10, sum = 0; 
for(i = 1; i <= num; ++i)  
{ 
sum = sum + i;  
}  
System.out.println("Sum of First 10 Natural Numbers is = " + sum);  
}  
}  