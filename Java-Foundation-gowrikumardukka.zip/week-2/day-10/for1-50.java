//for loop
import java.util.Scanner;
class forposi{
  public static void main(String[] args){
    Scanner input=new Scanner(System.in);
    System.out.println("the output is : ");
    int i=1;
    for(i=1;i<=50;i++){
      System.out.println(i);
    }
  }
}