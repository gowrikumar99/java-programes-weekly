//for loop
import java.util.Scanner;
class ForLoop{
  public static void main(String[] args){
    Scanner input=new Scanner(System.in);
    System.out.println("the output is : ");
    int i=50;
    for(i=50;i>0;i--){
      System.out.println(i);
    }
  }
}