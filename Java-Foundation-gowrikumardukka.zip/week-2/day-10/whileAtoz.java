class whileAtoz
  {
    public static void main(String args[])
    {      
   //Scanner sc=new Scanner(System.in);
     // System.out.println("enter the value");
     // char value=sc.next().charAt(0);
      for(char ch='a';ch<='z';ch++)
        {
          System.out.println(+ch);
        }
      
      
     
    }
  }