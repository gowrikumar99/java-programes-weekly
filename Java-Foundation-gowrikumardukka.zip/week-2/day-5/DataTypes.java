//data types
/* data types are two types those are 1.primetive data type(not change size) and 
2.non-primetive datatype  (user definr the size ex:string)
primetive datatype again two types
1.boolean datatype 2.numeric
numeric datatype again two types
1.charter data type 2.integer data type
chearter definr char 2.intergal data type again 2 types first one is integer
1.byte
2.short
3.int
4.long
second one is 1.float data type
              2.double datatype */
class DataTypes{
  public static void main(String[] args){
    int num=123;
    char ch='A';
    double d=123.456;
    float f =12.0f;
    boolean value=true;
    String name="gowrikumar";
    System.out.println("this is integer : "+num);
    System.out.println("this is character : "+ch);
    System.out.println("this is double : "+d);
    System.out.println("this is float: "+f);
    System.out.println("this is value : "+value);
    System.out.println("this is name : "+name);
    
    
    
    
  }
}