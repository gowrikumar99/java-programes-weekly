class StudentData{
  public static void main(String[] args){
    String name="gowrikumar";
    String branch="mechanical";
    int age=24;
    int rollno=156;
    long mobileNumber=6281208833l;
    int year=2020;
    boolean value=false;
    char ch='a';
    float nam=123.321f;
    System.out.println("this is my name :" +  name);
    System.out.println("this is my branch :" +  branch);
    System.out.println("this is my age :" +  age);
    System.out.println("this is my rollno :" +  rollno);
    System.out.println("this is my mobileNumber :" + mobileNumber);
    System.out.println("this is my passing year :" +  year);
    System.out.println("this is my value :" +  value);
    System.out.println("this is my charecter :" +  ch);
    System.out.println("this is my num :" +  nam);
  }
}