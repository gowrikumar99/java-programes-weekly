
public class Gowri{
  public static void myMethod(){
    System.out.println("i just got exicuted");
  }
  public static void main(String args[]){
    myMethod();
  }
}