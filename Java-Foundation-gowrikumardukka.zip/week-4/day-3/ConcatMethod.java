import java.util.Scanner;
class ConcatMethod{
  public static void main(String[] args){
    String str="hellow";
    String str1="gowrikumar";
    String Str2=str.concat(str1);
    System.out.println(Str2);
  }
  }
