import java.util.Scanner;
class CharAtFor{
  public static void main(String[] args){
    String str="hello";
    for(int i=0;i<str.length();i++){
      System.out.println(str.charAt(i));
    }
  }
}