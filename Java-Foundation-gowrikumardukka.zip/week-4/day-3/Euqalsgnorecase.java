//equals() & equalsIgnoreCase()
import java.util.Scanner;
class Sample
  {
    public static void main(String args[])
    {
      String s1="hai";
      String s2="hai";
      String s3="Hai";
      String s4="welcome";
   System.out.println(s1.equals(s2));
       System.out.println(s1.equals(s3));
       System.out.println(s1.equals(s4));
      System.out.println(s1.equalsIgnoreCase(s3));
    }
  }