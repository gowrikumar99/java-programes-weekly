//charAt()
import java.util.Scanner;
class Sample
  {
    public static void main(String args[])
    {
      String str="hello world";
      char ch=str.charAt(3);
      System.out.println("character is "+ch);
        
    }
  }