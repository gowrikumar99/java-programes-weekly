import java.util.Scanner;
class StringContains{
  public static void main(String[] args){
    String s1="my name is DGK";
    System.out.println(s1.contains("DGK"));
    System.out.println(s1.contains("GK"));
  }
}