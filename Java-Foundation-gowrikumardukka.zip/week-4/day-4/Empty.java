import java.util.Scanner;
class Empty{
  public static void main(String[] args){
    Scanner input=new Scanner(System.in);
    String str="";
    String str1="gowrikumar";
    System.out.println(str.isEmpty());
     System.out.println(str1.isEmpty());
  }
}