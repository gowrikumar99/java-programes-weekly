import java.util.Scanner;
class StringEndsWith{
  public static void main(String[] args){
    Scanner input=new Scanner(System.in);
    String str="HelloWorld";
    System.out.println(str.endsWith("0"));
  }
}