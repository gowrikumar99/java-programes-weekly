class Trim
  {
    public static void main(String args[])
    {
      String str="  Bit labs  ";
      String str1=str.trim();
      System.out.print(str1);
    }
  }