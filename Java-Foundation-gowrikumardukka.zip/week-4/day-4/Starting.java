import java.util.Scanner;
class Starting{
  public static void main(String[] args){
    Scanner input=new Scanner(System.in);
    String str="Universe";
    System.out.println(str.startsWith("U"));
  }
}