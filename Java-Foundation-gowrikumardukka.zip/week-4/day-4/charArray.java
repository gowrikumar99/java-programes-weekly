//toCharArray()
import java.util.Scanner;
class Sample
  {
    public static void main(String args[])
    {
     String s="bitlabs";
      char ch[]=s.toCharArray();
      for(int i=0;i<ch.length;i++)
        {
          System.out.println(ch[i]+" ");
        }
      
 
    }
  }