
import java.util.Scanner;
class Wordes1{
  public static void main(String[] args){
    Scanner input=new Scanner(System.in);
    String str="lahari";
    System.out.println("Name : " +str);
    int length=str.length();
    System.out.println("length : " +length);
  }
}