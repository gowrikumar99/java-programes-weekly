//indexOf()
import java.util.Scanner;
class Sample
  {
    public static void main(String args[])
    {
      String s="welcome toe bitlabs come";
      System.out.println(s.indexOf("come",7));
 
    }
  }