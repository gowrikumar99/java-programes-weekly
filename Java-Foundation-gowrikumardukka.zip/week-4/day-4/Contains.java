//Contains()
import java.util.Scanner;
class Sample
  {
    public static void main(String args[])
    {
      String s1="universe";
      String s2="welcome HelloWorld";
      boolean value=s1.contains("e");
      System.out.println(value);
     System.out.println(s2.contains("come"));
      System.out.println(s2.contains("ains"));
      System.out.println(s2.contains("llo"));
    }
  }