import java.util.scanner;
class FirstLetter{
  public static void main(String[] args){
    Scanner
  }
}