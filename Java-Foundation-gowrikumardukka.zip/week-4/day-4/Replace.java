class Replace
  {
    public static void main(String args[])
    {
      String s1="gkwri";
      String s2=s1.replace('k','');
      System.out.println(s2);
    }
  }