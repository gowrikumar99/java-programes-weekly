import java.util.Scanner;
class Equals{
  public static void main(String[] args){
    String s1="gowrikumar";
    String s2="gowrikumar";
    String s3="JAVA DEVELOPER";
    String s4="FULLSTACK";
    System.out.println(s1.equals(s2));
    System.out.println(s1.equals(s3));
    System.out.println(s1.equals(s4));
  }
}