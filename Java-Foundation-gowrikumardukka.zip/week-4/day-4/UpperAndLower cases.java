import java.util.Scanner;
class UpperAndLowerCases{
  public static void main(String[] args){
    Scanner input=new Scanner(System.in);
    String str="GOD";
    String str1="god";
    System.out.println(str.toUpperCase());
    System.out.println(str1.toLowerCase());
  }
}