class CompareToExample{  
public static void main(String args[]){  
String s1="hello";  
String s2="hello";  
String s3="world";  
String s4="gowri";  
String s5="kumar";  
System.out.println(s1.compareTo(s2));
System.out.println(s1.compareTo(s3));
System.out.println(s1.compareTo(s4));
System.out.println(s1.compareTo(s5));
}
}