public class Contains {  
    public static void main(String[] args) {  
        String str = "Hello gowrikumar";  
        boolean isContains = str.contains("hello");  
        System.out.println(isContains);  
        System.out.println(str.contains("gowrikumar"));
    }  
}  