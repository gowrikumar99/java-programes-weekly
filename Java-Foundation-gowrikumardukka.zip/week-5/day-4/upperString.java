class Main{
    public static void main(String args[])
    {
        String str="welcome";
        System.out.println(str.toUpperCase()); //method in String class
        char ch='a';
        System.out.println(Character.toUpperCase(ch)); //method in Character is a class
    }
}