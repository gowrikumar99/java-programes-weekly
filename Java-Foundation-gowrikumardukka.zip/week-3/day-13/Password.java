//Password verfication
import java.util.Scanner;
class Password{
  
}