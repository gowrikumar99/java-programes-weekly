class Method
  {
    public static void sumOfTwoNumbers(int a,int b)
    {
      int result=a+b;
      System.out.println("the value is "+result);
    }
    public static void main(String args[])
    {
      sumOfTwoNumbers(1,2);
      sumOfTwoNumbers(3,4);
      sumOfTwoNumbers(10,20);
      sumOfTwoNumbers(31,42);
      
      
    }
  }